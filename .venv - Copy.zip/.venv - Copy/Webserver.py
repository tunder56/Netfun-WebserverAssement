"""
Authors: Sehar Punia, Aneet Kaur, Daniel Mawston
Description:
This is a Basic websever that serves pages from the local directory on port 6789 to the local network.
-- client requests webpage on port 6789
-- program attempts to resolve the requested url to local file
-- returns local file via http to client to display webpage
-- if the file name cannot be resolved, webserver returns 404 error in all cases.
"""
# import socket module
from socket import *

# Server Setup
serverSocket = socket(AF_INET, SOCK_STREAM) # This line creates a socket object called serverSocket using the
                                            # IPv4 address family (AF_INET) and the TCP socket type (SOCK_STREAM).
ServerPort = 6789
serverSocket.bind(('192.168.1.50', ServerPort))  # This line binds the server socket to the address localhost and the specified port.
                                              #SPECIFYING 192.168.86.70 MEANS socket will only accept connections from processes running on the same machine where the server is running.
serverSocket.listen(1) # The listen method is called to tell the server to listen to incoming connections, and it specifies that the server can
                    # queue up to 1 connection request. (max of 1 connection)
while True:
    # Establish the connection
    print('Ready to serve...')
    connectionSocket, addr = serverSocket.accept()  # It waits to accept client request using serverSocket.accept().
    # When a client connects,  new socket connectionSocket is made for communication and the client's address is stored in addr .

    try: # Inside the try block, the code receives an HTTP request from the client,
        # decodes it, and extracts the requested filename from the request.
        # It then opens the requested file and reads its contents into output_data.
        message = connectionSocket.recv(1024).decode()  # Receive the message and decode it. The max bytes are 1024
        filename = message.split()[1]   # split() splits the received message string into words and extracts the second string [1] which is the filename in typical GET /filename...  GET  message format
        f = open(filename[1:])      # opens requested file on the server. filename includes / so [1:] removes the /
        output_data = f.read()          # reads content of the file and stores them in output_data variable

        # Send one HTTP response header line to client
        connectionSocket.send('HTTP/1.1 200 OK\r\nContent-Type: text/html \r\n\r\n'.encode()) #this sends 200 OK message to the client. encode() changes the messsage from string to bytes

        # Here, the code sends the content of the requested file to the client by iterating
        # through the characters of output_data and sending them one by one.
        # It also sends a blank line (\r\n) to mark the end of the response.
        #for i in range(0, len(output_data)):
        connectionSocket.send(output_data.encode())
        connectionSocket.send("\r\n".encode())
        connectionSocket.close()   #closes connection with the client
    except IOError:
        # n case of an IOError (e.g., if the requested file does not exist),
        # it sends a response indicating a "404 Not Found" error along with
        # an HTML error page.
        connectionSocket.send('HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\n\r\n'.encode())
        connectionSocket.send('<html><head></head><body><h1>404 Not Found</h1></body></html>'.encode())
        # Close client socket
        connectionSocket.close()
serverSocket.close()   # server socket closed
sys.exit()  # Terminate the program