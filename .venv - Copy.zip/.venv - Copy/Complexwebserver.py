"""
Authors: Sehar Punia, Aneet Kaur, Daniel Mawston
Description:
This is a Basic websever that serves pages from the local directory on port 6789 to the local network.
-- client requests webpage on port 6789
-- program attempts to resolve the requested url to local file
-- returns local file via http to client to display webpage
-- if the file name cannot be resolved, webserver returns 404 error in all cases.
"""
# import socket module
from socket import *

# Server Setup
serverSocket = socket(AF_INET, SOCK_STREAM)# This line creates a socket object called serverSocket using the
                                            # IPv4 address family (AF_INET) and the TCP socket type (SOCK_STREAM).
ServerPort = 6789
serverSocket.bind(('192.168.1.50', ServerPort))# This line binds the server socket to the address localhost and the specified port.

serverSocket.listen(1) # The listen method is called to tell the server to listen to incoming connections, and it specifies that the server can
                    # queue up to 1 connection request. (max of 1 connection)

while True:
    # Establish the connection
    print('Ready to serve...')
    connectionSocket, addr = serverSocket.accept()# It waits to accept client request using serverSocket.accept().
    # When a client connects,  new socket connectionSocket is made for communication and the client's address is stored in addr .


    try:
        # Inside the try block, the code receives an HTTP request from the client,
        # decodes it, and extracts the requested filename from the request.
        # It then opens the requested file and reads its contents into output_data.

        message = connectionSocket.recv(1024).decode() # Receive the message and decode it. The max bytes are 1024
        if not message:
            continue  # If no data received, continue to the next iteration

        filename = message.split()[1] # opens requested file on the server. filename includes / so [1:] removes the /
        try:
            # try to open the file as binary
            with open(filename[1:], 'rb') as f:
                output_data = f.read() # reads content of the file and stores them in output_data variable

            # Send one HTTP response header line to client
            response = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'.encode() + output_data
        except IOError:
            # in case of an IOError (e.g., if the requested file does not exist),
            # it saves a "404 Not Found" error to response  along with
            # an HTML error page.
            response = 'HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\n\r\n'.encode() + b'<html><head></head><body><h1>404 Not Found</h1></body></html>'

        # Send responce to client.
        connectionSocket.sendall(response)
        # Close client socket
        connectionSocket.close()
    except KeyboardInterrupt:
        break  # Break the loop if KeyboardInterrupt (Ctrl+C) is received
# Close client socket
serverSocket.close()